#!/usr/bin/env python3
"""
Overfishing Detection Pipeline - Local Execution
Runs the complete ETL pipeline locally using PySpark
"""

import os
import sys
from pyspark.sql import SparkSession

# Add transformations to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'transformations'))

from bronze_fishing_events import bronze_fishing_events
from silver_fishing_events import silver_fishing_events
from gold_fishing_features import gold_fishing_features


def create_spark_session():
    """Create local Spark session with appropriate configurations"""
    return (
        SparkSession.builder
        .appName("Overfishing Detection Pipeline")
        .master("local[*]")  # Use all available cores
        .config("spark.driver.memory", "4g")  # Adjust based on your system
        .config("spark.sql.shuffle.partitions", "8")  # Reduce for local execution
        .config("spark.sql.adaptive.enabled", "true")
        .getOrCreate()
    )


def main():
    print("="*60)
    print("Overfishing Detection Pipeline - Local Execution")
    print("="*60)
    
    # Get base directory
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    output_dir = os.path.join(base_dir, "output")
    
    # Create Spark session
    print("\nInitializing Spark session...")
    spark = create_spark_session()
    spark.sparkContext.setLogLevel("WARN")  # Reduce log verbosity
    
    try:
        # Bronze Layer
        print("\n" + "="*60)
        print("BRONZE LAYER - Raw Data Ingestion")
        print("="*60)
        bronze_fishing_events(
            spark,
            input_path=os.path.join(data_dir, "fishing_events.csv"),
            output_path=os.path.join(output_dir, "bronze_fishing_events")
        )
        
        # Silver Layer
        print("\n" + "="*60)
        print("SILVER LAYER - Data Cleaning & Validation")
        print("="*60)
        silver_fishing_events(
            spark,
            input_path=os.path.join(output_dir, "bronze_fishing_events"),
            output_path=os.path.join(output_dir, "silver_fishing_events")
        )
        
        # Gold Layer
        print("\n" + "="*60)
        print("GOLD LAYER - Feature Engineering for ML")
        print("="*60)
        gold_fishing_features(
            spark,
            input_path=os.path.join(output_dir, "silver_fishing_events"),
            output_path=os.path.join(output_dir, "gold_fishing_features")
        )
        
        print("\n" + "="*60)
        print("Pipeline completed successfully!")
        print("="*60)
        print(f"\nOutput location: {output_dir}")
        print("\nGenerated datasets:")
        print("  - bronze_fishing_events/     (raw data)")
        print("  - silver_fishing_events/     (cleaned data)")
        print("  - gold_fishing_features/     (ML features - parquet)")
        print("  - gold_fishing_features_csv/ (ML features - CSV)")
        print("\nYou can now use the gold_fishing_features dataset for ML training!")
        
    except Exception as e:
        print(f"\nERROR: Pipeline failed with error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    
    finally:
        spark.stop()


if __name__ == "__main__":
    main()

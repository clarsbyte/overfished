# Overfishing Detection Pipeline - Local Version

This is a complete local version of the Databricks overfishing detection pipeline that can run on your ASUS system using PySpark.

## Overview

The pipeline processes Global Fishing Watch (GFW) fishing events data through a medallion architecture:

- **Bronze Layer**: Raw data ingestion (99,999 fishing events)
- **Silver Layer**: Data cleaning, validation, and standardization
- **Gold Layer**: Aggregated vessel features for ML training

## Directory Structure

```
overfishing_pipeline_local/
├── data/                         # Input data files
│   ├── fishing_events.csv       # GFW fishing events (51.9 MB)
│   └── ship_detections.csv      # ASUS ship detections
├── transformations/              # ETL transformation scripts
│   ├── bronze_fishing_events.py
│   ├── silver_fishing_events.py
│   └── gold_fishing_features.py
├── output/                       # Generated datasets (created on run)
├── config/                       # Configuration files
├── run_pipeline.py              # Main execution script
├── requirements.txt             # Python dependencies
└── README.md                    # This file
```

## System Requirements

- **Python**: 3.8 or higher
- **RAM**: Minimum 4GB, recommended 8GB+
- **Disk Space**: ~500MB for output files
- **Java**: JDK 8 or 11 (required for PySpark)

## Installation

### 1. Install Java (if not already installed)

**Ubuntu/Debian:**
```bash
sudo apt update
sudo apt install openjdk-11-jdk
```

**Windows:**
Download and install Java JDK 11 from Oracle or use OpenJDK

**Verify:**
```bash
java -version
```

### 2. Install Python Dependencies

```bash
pip install -r requirements.txt
```

Or with conda:
```bash
conda install pyspark pandas numpy
```

## Running the Pipeline

Simply execute the main script:

```bash
python run_pipeline.py
```

Or make it executable and run directly:
```bash
chmod +x run_pipeline.py
./run_pipeline.py
```

## Pipeline Execution

The pipeline runs through 3 stages:

### Stage 1: Bronze Layer
- Loads raw fishing events CSV
- Infers schema automatically
- Saves as Parquet format

### Stage 2: Silver Layer
- Validates data quality (coordinates, timestamps, vessel IDs)
- Removes invalid records
- Deduplicates by event ID
- Renames columns to cleaner names
- Adds derived fields (event duration, high-risk flag)

### Stage 3: Gold Layer
- Aggregates by vessel (MMSI)
- Computes ML features:
  - Event counts and patterns
  - Distance and movement metrics
  - Temporal patterns (days active)
  - Geographic patterns (unique locations, distance from shore)
  - Risk indicators
- Saves as both Parquet and CSV formats

## Output Files

After running, check the `output/` directory:

- `bronze_fishing_events/` - Raw data in Parquet format
- `silver_fishing_events/` - Cleaned data in Parquet format
- `gold_fishing_features/` - ML features in Parquet format
- `gold_fishing_features_csv/` - ML features in CSV format (for easy viewing)

## Using the Output for ML

The gold layer dataset (`gold_fishing_features`) contains aggregated features per vessel:

```python
import pandas as pd
from glob import glob

# Read the CSV output
csv_files = glob('output/gold_fishing_features_csv/*.csv')
df = pd.read_csv(csv_files[0])

print(df.head())
print(f"Total vessels: {len(df)}")
print(f"Features: {list(df.columns)}")
```

Key ML features include:
- `total_events` - Number of fishing events
- `total_distance_km` - Total distance traveled
- `avg_speed_knots` - Average speed
- `days_active` - Days between first and last event
- `unique_locations` - Number of unique fishing locations
- `high_risk_events` - Count of high-risk events
- `avg_distance_from_shore_km` - Average distance from shore

## Performance Tuning

If you have limited RAM, edit `run_pipeline.py` and adjust:

```python
.config("spark.driver.memory", "2g")  # Reduce from 4g to 2g
.config("spark.sql.shuffle.partitions", "4")  # Reduce from 8 to 4
```

If you have more RAM (16GB+), increase for better performance:

```python
.config("spark.driver.memory", "8g")  # Increase to 8g
.config("spark.sql.shuffle.partitions", "16")  # Increase to 16
```

## Connecting to GitHub Project

To use this data in your GitHub project analysis:

1. The gold layer CSV files are ready to commit to your GitHub repo
2. You can also connect back to Databricks using:
   - Host: `https://dbc-bc20ec54-058b.cloud.databricks.com`
   - Warehouse ID: `bbb106a8b50a45ea`
   - Token: (generate at Settings → Developer → Access Tokens)

## Troubleshooting

**Error: Java not found**
- Install Java JDK 8 or 11
- Set JAVA_HOME environment variable

**Error: Out of memory**
- Reduce spark.driver.memory in run_pipeline.py
- Close other applications
- Process data in smaller batches

**Error: Module not found**
- Run: `pip install -r requirements.txt`
- Ensure you're in the correct virtual environment

## Data Sources

- **GFW Fishing Events**: Global Fishing Watch API (99,999 events, April 2025-2026)
- **Ship Detections**: ASUS GX-10 SAR processing results (100 real vessel positions)

## Next Steps

1. Run the pipeline to generate ML features
2. Train overfishing detection models using the gold layer
3. Integrate ASUS SAR ship detection results
4. Deploy model for real-time detection

## Support

For issues or questions about the Databricks implementation, refer to the original notebooks:
- Data Query Notebook: 1272932789548755
- Image Query Notebook: 1272932789548758

## License

This pipeline processes data from Global Fishing Watch. Please review GFW's data usage terms at:
https://globalfishingwatch.org/data-terms-of-use/

"""
Gold Layer - Fishing Features for Analytics and ML (Local Version)
Aggregated vessel activity features ready for analysis and model training.
"""

from pyspark.sql import SparkSession
from pyspark.sql import functions as F

def gold_fishing_features(spark, input_path, output_path):
    """
    Aggregate fishing activity by vessel for ML training.
    """
    print("Loading gold_fishing_features...")
    
    # Read silver data
    silver = spark.read.parquet(input_path)
    
    df = (
        silver
        .groupBy("vessel_mmsi", "vessel_name", "vessel_flag", "vessel_type")
        .agg(
            # Event counts
            F.count("event_id").alias("total_events"),
            F.countDistinct("event_id").alias("unique_events"),
            
            # Distance and movement patterns  
            F.sum("total_distance_km").alias("total_distance_km"),
            F.avg("average_speed_knots").alias("avg_speed_knots"),
            F.avg("event_duration_hours").alias("avg_event_duration_hours"),
            F.max("event_duration_hours").alias("max_event_duration_hours"),
            
            # Temporal patterns
            F.min("start_time").alias("first_seen"),
            F.max("end_time").alias("last_seen"),
            F.datediff(F.max("end_time"), F.min("start_time")).alias("days_active"),
            
            # Geographic patterns
            F.countDistinct("latitude", "longitude").alias("unique_locations"),
            F.avg("distance_from_shore_km").alias("avg_distance_from_shore_km"),
            F.min("distance_from_shore_km").alias("min_distance_from_shore_km"),
            F.max("distance_from_shore_km").alias("max_distance_from_shore_km"),
            F.avg("distance_from_port_km").alias("avg_distance_from_port_km"),
            
            # Risk indicators
            F.sum(F.when(F.col("potential_risk") == True, 1).otherwise(0)).alias("potential_risk_events"),
            F.sum(F.when(F.col("is_high_risk") == True, 1).otherwise(0)).alias("high_risk_events"),
            F.max(F.col("is_high_risk").cast("int")).alias("has_high_risk_flag"),
            
            # Regional coverage
            F.collect_set("eez_regions").alias("eez_regions_visited"),
            F.collect_set("rfmo_regions").alias("rfmo_regions_visited"),
            F.collect_set("fao_regions").alias("fao_regions_visited"),
            
            # Last known position
            F.last("latitude").alias("last_known_lat"),
            F.last("longitude").alias("last_known_lon"),
            F.last("start_time").alias("last_event_time")
        )
        .filter(F.col("total_events") > 0)
    )
    
    print(f"Aggregated {df.count():,} unique vessels")
    
    # Save as parquet
    df.write.mode("overwrite").parquet(output_path)
    print(f"Saved to {output_path}")
    
    # Also save as CSV for easy viewing
    df.coalesce(1).write.mode("overwrite").option("header", "true").csv(output_path + "_csv")
    print(f"Also saved CSV to {output_path}_csv")
    
    return df

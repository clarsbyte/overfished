"""
Silver Layer - Cleaned and Validated Fishing Events (Local Version)
Applies data quality checks, deduplication, and standardization.
"""

from pyspark.sql import SparkSession
from pyspark.sql import functions as F

def silver_fishing_events(spark, input_path, output_path):
    """
    Clean and validate fishing events:
    - Remove invalid records (null vessel IDs, invalid coordinates, bad timestamps)
    - Deduplicate by event ID
    - Standardize column names
    - Add derived columns
    """
    print("Loading silver_fishing_events...")
    
    # Read bronze data
    bronze_df = spark.read.parquet(input_path)
    
    # Apply data quality filters
    df = (
        bronze_df
        # Filter valid records
        .filter(F.col("`vessel.ssvid`").isNotNull())
        .filter((F.col("`position.lat`") >= -90) & (F.col("`position.lat`") <= 90))
        .filter((F.col("`position.lon`") >= -180) & (F.col("`position.lon`") <= 180))
        .filter(F.col("start").isNotNull() & F.col("end").isNotNull())
        .filter(F.col("start") <= F.col("end"))
        # Deduplicate by event ID
        .dropDuplicates(["id"])
        # Rename columns to simpler names
        .withColumnRenamed("id", "event_id")
        .withColumnRenamed("type", "event_type")
        .withColumnRenamed("start", "start_time")
        .withColumnRenamed("end", "end_time")
        .withColumnRenamed("vessel.id", "vessel_id")
        .withColumnRenamed("vessel.name", "vessel_name")
        .withColumnRenamed("vessel.ssvid", "vessel_mmsi")
        .withColumnRenamed("vessel.flag", "vessel_flag")
        .withColumnRenamed("vessel.type", "vessel_type")
        .withColumnRenamed("vessel.public_authorizations", "vessel_authorizations")
        .withColumnRenamed("fishing.vessel_public_authorization_status", "authorization_status")
        .withColumnRenamed("position.lat", "latitude")
        .withColumnRenamed("position.lon", "longitude")
        .withColumnRenamed("fishing.total_distance_km", "total_distance_km")
        .withColumnRenamed("fishing.average_speed_knots", "average_speed_knots")
        .withColumnRenamed("fishing.potential_risk", "potential_risk")
        .withColumnRenamed("distances.start_distance_from_shore_km", "distance_from_shore_km")
        .withColumnRenamed("distances.start_distance_from_port_km", "distance_from_port_km")
        .withColumnRenamed("regions.eez", "eez_regions")
        .withColumnRenamed("regions.rfmo", "rfmo_regions")
        .withColumnRenamed("regions.fao", "fao_regions")
        .withColumnRenamed("regions.mpa", "mpa_regions")
        # Add processing timestamp
        .withColumn("processed_at", F.current_timestamp())
        # Calculate event duration in hours
        .withColumn("event_duration_hours", 
                   F.round((F.unix_timestamp("end_time") - F.unix_timestamp("start_time")) / 3600, 2))
        # Add high-risk flag
        .withColumn("is_high_risk", 
                   F.when((F.col("potential_risk") == True) & (F.col("distance_from_shore_km") > 200), True)
                    .otherwise(False))
    )
    
    print(f"Cleaned to {df.count():,} valid fishing events")
    
    # Save as parquet
    df.write.mode("overwrite").parquet(output_path)
    print(f"Saved to {output_path}")
    
    return df

"""
Bronze Layer - Raw Fishing Events (Local Version)
Loads raw CSV data from GFW API ingestion with minimal transformation.
"""

from pyspark.sql import SparkSession

def bronze_fishing_events(spark, input_path, output_path):
    """
    Load raw fishing events CSV from local storage.
    No filtering or cleaning - preserve all raw data for audit and reprocessing.
    """
    print("Loading bronze_fishing_events...")
    
    df = (
        spark.read
        .format("csv")
        .option("header", "true")
        .option("inferSchema", "true")
        .load(input_path)
    )
    
    print(f"Loaded {df.count():,} raw fishing events")
    
    # Save as parquet
    df.write.mode("overwrite").parquet(output_path)
    print(f"Saved to {output_path}")
    
    return df
